package com.seunome.controle_verbas_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ControleVerbasBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
